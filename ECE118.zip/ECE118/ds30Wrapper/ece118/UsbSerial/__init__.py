import serial
import threading
import queue
import serial.tools.list_ports
import time

RAWQUEUESIZE = 2048





class UsbSerial(object):
	def __init__(self, Port = None, BaudRate = 115200, idleDtr=True, idleRts=True):


		# store the port info in instance variables
		self.Port = Port
		self.BaudRate = BaudRate
		# Preserve the historical asserted idle levels; board wiring determines polarity.
		self.idleDtr = bool(idleDtr)
		self.idleRts = bool(idleRts)
		self._portLock = threading.RLock()
		self.externalOwner = False
		self._savedConnectionState = None
		self.autoReConnect = False
		self.lastError = None

		# set up the dictionary of queues
		self.receivedBytesQueues = list()

		# set up the list for error handlers
		self.errorBackList = list()

		# set up list for outgoing messages
		self.outMessageCallBacks = list()

		# set up queue for outgoing serial as the serial write is blocking
		self.outputQueue = queue.Queue()

		# count packets
		self.packetCountReceiving = 0
		self.packetCountSending = 0

		# connect to the port but first set the activeFlag and create a ref to the port
		self.activeConnection = False
		self.serialPort = None
		self.Connect()

		# set up the threaded input buffer
		self.incomingThread = threading.Thread(target=self.handleIncoming, name='IncomingHandler')
		self.incomingThread.daemon = True
		self.incomingThread.start()

		# set up the threaded output buffer
		self.outputThread = threading.Thread(target=self.handleOutGoing, name='outgoingHandler')
		self.outputThread.daemon = True
		self.outputThread.start()

		return

	@staticmethod
	def listSerialPorts():
		return [potPort.device for potPort in serial.tools.list_ports.comports()]

	def _recordError(self, action, error):
		self.lastError = f"{action} on {self.Port}: {error}"
		for callback in self.errorBackList:
			threading.Thread(target=callback, args=(self.lastError,), daemon=True).start()

	def _closePort(self):
		# Caller holds _portLock, so no read/write/open can overlap close.
		self.activeConnection = False
		if self.serialPort is not None:
			try:
				self.serialPort.close()
			except (OSError, serial.SerialException) as error:
				self._recordError("Closing serial port", error)
				return False
			self.serialPort = None
		return True

	def Connect(self):
		with self._portLock:
			if self.externalOwner:
				return False
			if self.activeConnection:
				return True
			if not self._closePort():
				return False
			try:
				if self.Port is None:
					for candidate in serial.tools.list_ports.comports():
						if candidate.device != 'COM1':
							self.Port = candidate.device
				if not self.Port:
					self._recordError("Opening serial port", "No port selected or available")
					return False
				self.serialPort = serial.Serial()
				self.serialPort.baudrate = self.BaudRate
				self.serialPort.port = self.Port
				# Nonblocking reads and bounded writes make ownership handoff finite.
				self.serialPort.timeout = 0
				self.serialPort.write_timeout = 0.5
				self.serialPort.dsrdtr = False
				self.serialPort.rtscts = False
				self.serialPort.xonxoff = False
				self.serialPort.dtr = self.idleDtr
				self.serialPort.rts = self.idleRts
				self.serialPort.open()
				self.activeConnection = True
				self.lastError = None
				return True
			except (OSError, serial.SerialException, ValueError) as error:
				self._recordError("Opening serial port", error)
				self._closePort()
				return False

	def Disconnect(self):
		with self._portLock:
			if self.externalOwner:
				return False
			self.autoReConnect = False
			return self._closePort()

	def beginExternalUse(self):
		"""Reserve the port for the loader, including all its retry attempts."""
		with self._portLock:
			if self.externalOwner:
				return False
			self._savedConnectionState = (self.activeConnection, self.autoReConnect)
			self.externalOwner = True
			self.autoReConnect = False
			if not self._closePort():
				self.externalOwner = False
				_, self.autoReConnect = self._savedConnectionState
				self._savedConnectionState = None
				return False
			# Never send stale terminal input to a newly programmed application.
			while True:
				try:
					self.outputQueue.get_nowait()
				except queue.Empty:
					break
			return True

	def endExternalUse(self):
		with self._portLock:
			if not self.externalOwner:
				return True
			wasConnected, reconnect = self._savedConnectionState
			self._savedConnectionState = None
			self.externalOwner = False
			self.autoReConnect = reconnect
			return self.Connect() if wasConnected else True

	def registerQueue(self, inQueue):
		if type(inQueue) is not queue.Queue:
			return False
		else:
			self.receivedBytesQueues.append(inQueue)
		return True

	# def deregisterMessageHandler(self, messageID, functionPointer):
	# 	if type(messageID) is not MessageIDs:
	# 		return False
	# 	if messageID.value in self.callBackDict:
	# 		self.callBackDict[messageID.value].remove(functionPointer)
	# 	return True

	# def registerOutGoingMessageHandler(self, functionPointer):
	# 	"""gets a callback on outgoing messages, this is for all messages, up to application to filter"""
	# 	self.outMessageCallBacks.append(functionPointer)

	def registerErrorHandler(self, functionPointer):
		"""this is for errors in the serial stream, not in the packets"""
		self.errorBackList.append(functionPointer)
		return


	def handleIncoming(self):
		while True:
			data = b""
			with self._portLock:
				if not self.externalOwner:
					if not self.activeConnection and self.autoReConnect:
						self.Connect()
					if self.activeConnection:
						try:
							data = self.serialPort.read(min(self.serialPort.in_waiting, RAWQUEUESIZE) or 1)
						except (OSError, serial.SerialException) as error:
							self.handleError(error)
			for value in data:
				for target in self.receivedBytesQueues:
					try:
						target.put_nowait(bytes([value]))
					except queue.Full:
						self._recordError("Receiving serial data", "Receive queue full; byte dropped")
			time.sleep(0.01 if self.activeConnection else 0.1)

	def handleOutGoing(self):
		while True:
			with self._portLock:
				if self.activeConnection and not self.externalOwner:
					try:
						value = self.outputQueue.get_nowait()
					except queue.Empty:
						pass
					else:
						try:
							if self.serialPort.write(bytes([value])) != 1:
								raise serial.SerialTimeoutException("Incomplete serial write")
						except (OSError, serial.SerialException) as error:
							self.handleError(error)
						else:
							continue
			time.sleep(0.01)

	def handleError(self, inException):
		with self._portLock:
			self._recordError("Serial I/O", inException)
			self._closePort()

	def sendBytes(self, message):
		with self._portLock:
			if self.externalOwner:
				return False
			for value in message:
				self.outputQueue.put(value)
			return True

	def setAutoConnectMode(self, reconnectMode):
		with self._portLock:
			if not self.externalOwner:
				self.autoReConnect = bool(reconnectMode)


if __name__ == "__main__":
	import time
	import random
	import queue


	portInstance = UsbSerial()
	print("Port: {} Baudrate: {} Active: {}".format(portInstance.Port, portInstance.BaudRate, portInstance.activeConnection))

	tempQueue = queue.Queue()

	portInstance.registerQueue(tempQueue)

	while True:
		while not tempQueue.empty():
			print(tempQueue.get().decode('ascii'), end='')
		time.sleep(.1)

