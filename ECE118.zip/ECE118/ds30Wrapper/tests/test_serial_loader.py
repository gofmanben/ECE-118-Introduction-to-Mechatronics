"""Hardware-free regression tests: python -m unittest discover -s Code/Python/tests."""
import os
from pathlib import Path
import queue
import sys
import threading
import unittest
from unittest.mock import MagicMock, patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import serial
from PyQt5.QtCore import QProcess
from PyQt5.QtWidgets import QApplication
from ece118.UsbSerial import UsbSerial
from ece118.guiWidgets.ds30Loader import ds30Loader
from ece118.guiWidgets.SerialControl import SerialControl


class SerialTests(unittest.TestCase):
    def setUp(self):
        self.factory = patch("ece118.UsbSerial.serial.Serial").start()
        self.addCleanup(patch.stopall)
        # Test worker iterations explicitly; do not leave permanent daemon workers.
        with patch("ece118.UsbSerial.threading.Thread"):
            self.port = UsbSerial("TEST", idleDtr=False, idleRts=False)
        self.device = self.factory.return_value

    def test_explicit_lines_and_bounded_io_before_open(self):
        self.assertFalse(self.device.dtr)
        self.assertFalse(self.device.rts)
        self.assertFalse(self.device.dsrdtr)
        self.assertFalse(self.device.rtscts)
        self.assertEqual(self.device.timeout, 0)
        self.assertEqual(self.device.write_timeout, 0.5)
        self.device.open.assert_called_once()
        self.assertTrue(self.port.Connect())
        self.assertEqual(self.factory.call_count, 1)

    def test_handoff_blocks_connect_and_send_and_restores_state(self):
        self.port.setAutoConnectMode(True)
        self.port.sendBytes(b"stale")
        self.assertTrue(self.port.beginExternalUse())
        self.assertFalse(self.port.Connect())
        self.assertFalse(self.port.sendBytes(b"blocked"))
        self.assertFalse(self.port.Disconnect())
        self.port.setAutoConnectMode(True)
        self.assertFalse(self.port.autoReConnect)
        self.assertTrue(self.port.outputQueue.empty())
        self.assertTrue(self.port.endExternalUse())
        self.assertTrue(self.port.activeConnection)
        self.assertTrue(self.port.autoReConnect)
        self.assertEqual(self.factory.call_count, 2)

    def test_disconnected_handoff_preserves_reconnect_without_opening(self):
        self.port.Disconnect()
        self.port.setAutoConnectMode(True)
        self.assertTrue(self.port.beginExternalUse())
        self.assertFalse(self.port.autoReConnect)
        self.assertTrue(self.port.endExternalUse())
        self.assertFalse(self.port.activeConnection)
        self.assertTrue(self.port.autoReConnect)
        self.assertEqual(self.factory.call_count, 1)

    def test_disconnect_disables_reconnect_even_when_already_disconnected(self):
        self.port.Disconnect()
        self.port.setAutoConnectMode(True)
        self.port.Disconnect()
        self.assertFalse(self.port.autoReConnect)

    def test_close_failure_prevents_loader_handoff(self):
        self.device.close.side_effect = OSError("close failed")
        self.assertFalse(self.port.beginExternalUse())
        self.assertFalse(self.port.externalOwner)
        self.assertIn("close failed", self.port.lastError)
        self.assertIs(self.port.serialPort, self.device)

    def test_open_error_is_reported_and_handle_closed(self):
        self.port.Disconnect()
        self.device.open.side_effect = serial.SerialException("access denied")
        self.assertFalse(self.port.Connect())
        self.assertFalse(self.port.activeConnection)
        self.assertIsNone(self.port.serialPort)
        self.assertIn("TEST", self.port.lastError)
        self.assertIn("access denied", self.port.lastError)

    def test_handoff_waits_for_current_io(self):
        entered = threading.Event()
        release = threading.Event()
        completed = threading.Event()

        def io_operation():
            with self.port._portLock:
                entered.set()
                release.wait(2)

        def handoff():
            self.port.beginExternalUse()
            completed.set()

        reader = threading.Thread(target=io_operation)
        loader = threading.Thread(target=handoff)
        reader.start()
        self.assertTrue(entered.wait(2))
        loader.start()
        try:
            self.assertFalse(completed.wait(0.05))
            self.device.close.assert_not_called()
        finally:
            release.set()
            reader.join(2)
            loader.join(2)
        self.assertTrue(completed.is_set())
        self.assertTrue(self.port.externalOwner)

    def test_empty_reads_do_not_enqueue_empty_bytes(self):
        destination = queue.Queue()
        self.port.registerQueue(destination)
        self.device.in_waiting = 0
        self.device.read.return_value = b""
        with patch("ece118.UsbSerial.time.sleep", side_effect=InterruptedError):
            with self.assertRaises(InterruptedError):
                self.port.handleIncoming()
        self.assertTrue(destination.empty())

    def test_receive_error_closes_handle_and_reports_failure(self):
        self.device.in_waiting = 1
        self.device.read.side_effect = serial.SerialException("Device unplugged")
        with patch("ece118.UsbSerial.time.sleep", side_effect=InterruptedError):
            with self.assertRaises(InterruptedError):
                self.port.handleIncoming()
        self.assertFalse(self.port.activeConnection)
        self.assertIsNone(self.port.serialPort)
        self.assertIn("Device unplugged", self.port.lastError)

    def test_write_timeout_closes_handle_and_reports_failure(self):
        self.port.sendBytes(b"x")
        self.device.write.side_effect = serial.SerialTimeoutException("Write stalled")
        with patch("ece118.UsbSerial.time.sleep", side_effect=InterruptedError):
            with self.assertRaises(InterruptedError):
                self.port.handleOutGoing()
        self.assertFalse(self.port.activeConnection)
        self.assertIsNone(self.port.serialPort)
        self.assertIn("Write stalled", self.port.lastError)


class LoaderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.port = MagicMock()
        self.port.Port = "TEST"
        self.port.lastError = None
        self.port.externalOwner = False
        self.port.beginExternalUse.return_value = True
        self.port.endExternalUse.return_value = True
        # Avoid touching real user preferences or executing an installed loader.
        with patch("ece118.guiWidgets.ds30Loader.QSettings"), \
             patch.object(ds30Loader, "loadFileList"), \
             patch.object(ds30Loader, "refreshExecutablePath"):
            self.widget = ds30Loader(self.port)
        self.addCleanup(self.widget.deleteLater)
        self.widget.executablePath = Path("ds30LoaderConsole.exe")
        self.process = MagicMock()
        self.process.readAllStandardOutput.return_value = b""
        self.widget.process = self.process
        self.widget.currentOperation = {"name": "check", "success": "OK", "failure": "Failed"}
        self.widget._ownsSerialPort = True
        self.widget.pendingLaunchAttempts = [{"port": "TEST", "reset_profile": "active_low"}]
        self.results = []
        self.widget.operationFinished.connect(lambda name, ok: self.results.append((name, ok)))

    def test_final_output_is_drained_before_success_check(self):
        self.process.readAllStandardOutput.return_value = b"Found boot loader version 1"
        self.widget._handleProcessFinished(0, QProcess.NormalExit)
        self.assertEqual(self.results, [("check", True)])
        self.port.endExternalUse.assert_called_once()

    def test_success_text_cannot_override_failed_exit(self):
        self.widget.processOutput = "Found boot loader version 1"
        self.widget._handleProcessFinished(1, QProcess.NormalExit)
        self.assertEqual(self.results, [("check", False)])

    def test_crash_keeps_port_reserved_until_finished(self):
        self.widget._handleProcessError(QProcess.Crashed)
        self.port.endExternalUse.assert_not_called()
        self.assertTrue(self.widget.isBusy())
        self.widget._handleProcessFinished(1, QProcess.CrashExit)
        self.assertEqual(self.results, [("check", False)])
        self.port.endExternalUse.assert_called_once()

    def test_failed_start_restores_port_once(self):
        self.process.errorString.return_value = "Executable not found"
        self.widget._handleProcessError(QProcess.FailedToStart)
        self.widget._handleProcessFinished(1, QProcess.CrashExit)
        self.assertEqual(self.results, [("check", False)])
        self.port.endExternalUse.assert_called_once()
        self.assertIn("Executable not found", self.widget.consoleOutput.toPlainText())

    def test_burn_timeout_does_not_repeat_write(self):
        self.widget.currentOperation["name"] = "burn"
        self.widget.pendingLaunchAttempts *= 2
        self.widget.processOutput = "Write timed out"
        with patch.object(self.widget, "_launchProcessAttempt") as launch:
            self.widget._handleProcessFinished(1, QProcess.NormalExit)
        launch.assert_not_called()
        self.assertEqual(self.results, [("burn", False)])

    def test_probe_retry_keeps_port_reserved(self):
        self.widget.pendingLaunchAttempts *= 2
        self.widget.processOutput = "hi timed out"
        with patch.object(self.widget, "_launchProcessAttempt") as launch:
            self.widget._handleProcessFinished(1, QProcess.NormalExit)
        launch.assert_called_once()
        self.port.endExternalUse.assert_not_called()
        self.assertTrue(self.widget.isBusy())

    def test_reconnect_failure_is_visible(self):
        self.port.endExternalUse.return_value = False
        self.port.lastError = "access denied"
        self.widget._cleanupAfterProcess()
        self.assertIn("serial reconnect failed: access denied", self.widget.consoleOutput.toPlainText())

    def test_failed_handoff_does_not_launch(self):
        self.port.beginExternalUse.return_value = False
        self.port.lastError = "close failed"
        with patch.object(self.widget, "_launchProcessAttempt") as launch:
            self.widget._startProcess("check", "Checking", "OK", "Failed")
        launch.assert_not_called()
        self.assertFalse(self.widget.isBusy())
        self.assertIn("close failed", self.widget.consoleOutput.toPlainText())

    def test_native_and_windows_hello_windows(self):
        windows = self.widget.commonLoaderArguments({})
        self.assertIn("--ht=1000", windows)
        self.assertIn("-m", windows)
        self.widget.executablePath = Path("ds30_loader_native_console_macos_arm64")
        native = self.widget.commonLoaderArguments({})
        self.assertEqual(native[native.index("--ht") + 1], "1000")

    def test_serial_controls_locked_during_loader(self):
        self.port.externalOwner = True
        self.port.listSerialPorts.return_value = ["TEST"]
        self.port.autoReConnect = False
        control = SerialControl(self.port)
        try:
            for widget in (control.connectButton, control.disconnectButton,
                           control.serialPortSelection, control.rescanPortsButton,
                           control.toggleAutoConnect):
                self.assertFalse(widget.isEnabled())
            control.connect()
            self.port.Connect.assert_not_called()
        finally:
            control.Timer.stop()
            control.deleteLater()


if __name__ == "__main__":
    unittest.main()
